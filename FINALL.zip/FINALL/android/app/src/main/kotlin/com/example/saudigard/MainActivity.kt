package com.example.saudigard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
